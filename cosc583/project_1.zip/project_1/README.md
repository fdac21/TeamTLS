## Compiling and Running
1) Run ```make```
2) Run ```./aes```
3) For output comparison, run ```./aes | diff -y appendix_c.txt -```

## Statements
* I did not use any materials outside of the provided ones when completing this lab
* As far as I'm aware, all of my test cases pass except for the test cases for equivalent inverse